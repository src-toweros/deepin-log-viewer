<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!message" line="0"/>
			<source>Authentication is required to clear the log</source>
			<translation>Cal autenticació per netejar el registre.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!description" line="0"/>
			<source>authentication</source>
			<translation>autenticació</translation>
		</message>
	</context>
</TS>