<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!message" line="0"/>
			<source>Authentication is required to clear the log</source>
			<translation>Voer je wachtwoord in om het logboek te wissen</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!description" line="0"/>
			<source>authentication</source>
			<translation>authenticatie</translation>
		</message>
	</context>
</TS>