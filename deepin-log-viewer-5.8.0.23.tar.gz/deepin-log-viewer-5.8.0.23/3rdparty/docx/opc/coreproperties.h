#ifndef COREPROPERTIES_H
#define COREPROPERTIES_H

namespace Docx {

class CoreProperties
{
public:
    CoreProperties();
    virtual ~CoreProperties();
};
}
#endif // COREPROPERTIES_H
