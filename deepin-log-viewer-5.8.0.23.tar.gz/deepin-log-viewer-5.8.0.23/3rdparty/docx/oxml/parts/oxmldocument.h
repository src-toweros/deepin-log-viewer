#ifndef OXMLDCOXDOCUMENT_H
#define OXMLDCOXDOCUMENT_H

namespace Docx
{
class CT_Body
{
public:
    CT_Body();
    virtual ~CT_Body();

private:

};
}


#endif // DOCUMENT_H
