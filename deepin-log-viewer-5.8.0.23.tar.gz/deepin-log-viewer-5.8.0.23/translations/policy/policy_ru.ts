<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerAuth!message" line="0"/>
			<source>Authentication is required to view the log</source>
			<translation>Аутентификация необходима для просмотра журнала</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerAuth!description" line="0"/>
			<source>authentication</source>
			<translation>Аутентификация</translation>
		</message>
	</context>
</TS>