#include "oxmldocument.h"

namespace Docx
{

CT_Body::CT_Body()
{

}

CT_Body::~CT_Body()
{

}

}
