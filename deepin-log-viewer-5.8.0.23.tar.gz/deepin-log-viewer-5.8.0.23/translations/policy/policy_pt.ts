<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!message" line="0"/>
			<source>Authentication is required to clear the log</source>
			<translation>É necessária a autenticação para limpar o registo</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!description" line="0"/>
			<source>authentication</source>
			<translation>autenticação</translation>
		</message>
	</context>
</TS>