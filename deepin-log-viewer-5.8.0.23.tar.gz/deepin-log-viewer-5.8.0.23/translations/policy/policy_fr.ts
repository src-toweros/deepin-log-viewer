<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!message" line="0"/>
			<source>Authentication is required to clear the log</source>
			<translation>L&apos;authentification est requise pour effacer le journal</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!description" line="0"/>
			<source>authentication</source>
			<translation>authentification</translation>
		</message>
	</context>
</TS>