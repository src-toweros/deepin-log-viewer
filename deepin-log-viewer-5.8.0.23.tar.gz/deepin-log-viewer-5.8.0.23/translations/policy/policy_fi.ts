<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!message" line="0"/>
			<source>Authentication is required to clear the log</source>
			<translation>Lokin tyhjentäminen edellyttää todennusta</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.logViewerTruncate!description" line="0"/>
			<source>authentication</source>
			<translation>todennus</translation>
		</message>
	</context>
</TS>